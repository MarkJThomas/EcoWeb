+++
title = "Contacter"
layout = "contact"
netlify = false
emailservice = "formspree.io/example@email.com"
contactname = "Votre nom"
contactemail = "Votre email"
contactsubject = "Matière"
contactmessage = "Votre message"
contactlang = "fr"
contactanswertime = 24
+++
